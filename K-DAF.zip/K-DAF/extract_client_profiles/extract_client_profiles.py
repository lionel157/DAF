import json
import time
from tqdm import tqdm
from openai import OpenAI

client = OpenAI(
    api_key="",
    base_url=""
)

MODEL = "deepseek-chat"
MAX_RETRIES = 3
SLEEP = 2
PROCESS_LIMIT = 2000
PROMPT_TEMPLATE = (
    "You are a psychological profiling assistant.\n"
    "Given the user's persona, distorted thought, and cognitive distortion type, "
    "generate a structured user profile in JSON format.\n\n"
    "Persona: {persona}\n"
    "Thought: {thought}\n"
    "Cognitive distortion type: {pattern}\n"
    "Definition: {pattern_def}\n\n"
    "If some information is missing, REASONABLY INFER it based on semantics and cultural context. "
    "Return ONLY a valid JSON object with fields:\n"
    "{{\n"
    "  'gender': str,  \n"
    "  'age': int,  \n"
    "  'occupation': str,  \n"
    "  'education_level': str,  \n"
    "  'big5': {{'openness': str, 'conscientiousness': str, 'extraversion': str, 'agreeableness': str, 'neuroticism': str}},  \n"
    "}}\n"
)

def extract_json(text: str):
    text = text.strip()
    if text.startswith("{") and text.endswith("}"):
        try:
            return json.loads(text)
        except Exception:
            pass
    start, depth = None, 0
    for i, ch in enumerate(text):
        if ch == "{":
            if start is None:
                start = i
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                sub = text[start:i + 1]
                try:
                    return json.loads(sub)
                except Exception:
                    pass
    return {}

def call_deepseek(persona, thought, pattern, pattern_def):
    prompt = PROMPT_TEMPLATE.format(
        persona=persona,
        thought=thought,
        pattern=pattern,
        pattern_def=pattern_def
    )
    for attempt in range(MAX_RETRIES):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": "You are a JSON-only assistant."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.3,
                max_tokens=500
            )
            content = response.choices[0].message.content
            
            data = extract_json(content)
            if data:
                return data
        except Exception as e:
            if attempt < MAX_RETRIES - 1:
                time.sleep(SLEEP * (attempt + 1))
            else:
                return {"_error": f"API call failed: {str(e)}"}
    return {"_error": "Maximum retries reached, failed to obtain valid JSON response"}

def main(input_file="persona_used_for_test.txt", output_file="persona_used_for_test.json"):
    """Main function: Read input file, call API, and write results to a single JSON file (JSON array format)"""
    print(f"Starting processing of input file: {input_file}")
    
    all_personas = []

    try:
        with open(input_file, "r", encoding="utf-8") as f_in:
            lines = f_in.readlines()
            
            limited_lines = lines[:PROCESS_LIMIT]
            print(f"Will process only the first {len(limited_lines)} records from the file (limited to {PROCESS_LIMIT})...")
        
            for line in tqdm(limited_lines, desc="Generating data and collecting results", total=len(limited_lines)):
                line = line.strip()
                if not line:
                    continue

                item = {}
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    tqdm.write(f"Skipping invalid JSON line: {line[:50]}...")
                    continue

                persona_in = item.get("persona", "")
                thought = item.get("thought", "")
                pattern = item.get("pattern", "")
                pattern_def = item.get("pattern_def", "")

                profile = call_deepseek(persona_in, thought, pattern, pattern_def)

                if "_error" in profile:
                    tqdm.write(f"Failed to process line ({thought[:20]}...): {profile['_error']}")
                    continue

                persona_dict = {
                    "gender": profile.get('gender', 'unknown'),
                    "age": profile.get('age', None),
                    "occupation": profile.get('occupation', 'unknown'),
                    "big5": profile.get('big5', {}),
                    "education_level": profile.get('education_level', 'unknown'),
                    "thought": thought,
                }

                all_personas.append(persona_dict)

        with open(output_file, "w", encoding="utf-8") as f_out:
            json.dump(all_personas, f_out, ensure_ascii=False, indent=4)

        print(f"Processing completed. Simplified JSON array results ({len(all_personas)} records) have been saved to: {output_file}")
    except FileNotFoundError:
        print(f"Error: Input file {input_file} not found. Please ensure the file exists.")
    except Exception as e:
        print(f"A fatal error occurred: {e}")

if __name__ == "__main__":
    main()