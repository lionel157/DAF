from openai import OpenAI
import json
import re
import os
from time import sleep


client = OpenAI(
    api_key="sk-***********************",
    base_url="https://api.openai.com/v1"
)


INPUT_FILE_NAME = "./dataset/PsyDAF.json"
OUTPUT_FILE_NAME = "./eval_result/PsyDAF_eval_scored.json"

MEAN_SCORES_OUTPUT_FILE = "./eval_result/PsyDAF_eval_mean_scores.json"

SCORING_CRITERIA = {
    "WAI": {
        "Goal": {
            "4": "Counselor and I collaborate on setting goals for my therapy.",
            "6": "Counselor and I are working towards mutually agreed upon goals.",
            "8": "Counselor and I agree on what is important for me to work on.",
            "11": "Counselor and I have established a good understanding of the kind of changes that would be good for me."
        },
        "Task": {
            "1": "As a result of these sessions I am clearer as to how I might be able to change.",
            "2": "What I am doing in therapy gives me new ways of looking at my problem.",
            "10": "I feel that the things I do in therapy will help me to accomplish the changes that I want.",
            "12": "I believe the way we are working with my problem is correct."
        },
        "Bond": {
            "3": "I believe counselor likes me.",
            "5": "Counselor and I respect each other.",
            "7": "I feel that counselor appreciates me.",
            "9": "I feel counselor cares about me even when I do things that he/she does not approve of."
        }
    },
    "BLRI": {
        "Cognitive_Empathy": {
            "3": "Counselor nearly always sees exactly what I mean.",
            "5": "Counselor fully understands my perspectives.",
            "7": "Counselor realizes what I mean even when I have difficulty in saying it.",
            "8": "Counselor listens attentively and grasps my thoughts and feelings.",
            "9": "Counselor usually understands the whole of what I mean."
        },
        "Affective_Empathy": {
            "1": "Counselor usually senses or realizes what I am feeling.",
            "2": "Counselor responds to both my words and underlying feelings.",
            "4": "Counselor appreciates just how the things I experience feel to me.",
            "10": "Counselor recognizes my sensitivity regarding the topics we discuss."
        },
        "Differentiated_Empathy": {
            "12": "When I am hurting or upset counselor recognizes my painful feelings without becoming upset him/herself."
        },
        "Inner_Pattern": {
            "6": "Counselor’s attitude supports objective understanding of me.",
            "11": "Counselor responds flexibly, making me feel heard and understood."
        }
    },
    "CCS": {
        "Probing": {
            "1": "Includes Minimal Encouragers & Door Openers such as 'Tell me more about...', 'Hmm'",
            "2": "Use of Appropriate Open & Closed Questioning"
        },
        "Facilitate Therapeutic Environment": {
            "10": "Expresses accurate empathy & care. Counselor is present and open.",
            "11": "Counselor expresses appropriate respect & unconditional positive regard"
        },
        "Reflecting": {
            "3": "Basic Reflection of Content/Paraphrasing",
            "4": "Reflection of Feelings",
            "5": "Summarizing content, feelings, behaviors, & future plans",
            "6": "Advanced Reflection of Meaning including Values and Core Beliefs"
        },
        "Change_Facilitation": {
            "7": "Counselor challenges client to recognize inconsistencies.",
            "8": "Counselor collaborates with client to establish attainable goals",
            "9": "Counselor focuses client on therapeutic goals"
        }
    }
}



def enforce_range(score, scale):
    if score is None or not isinstance(score, (int, float)):
        return None
    if scale == "BLRI":
        return max(-3, min(3, int(round(score))))
    return max(1, min(5, int(round(score))))


def build_prompt(conversation, criteria):
    prompt = f"""
You are a patient in psychological counseling, evaluating your experience based on a counseling assessment questionnaire. Please provide a score from the Patient's perspective, referring to the following conversation and the item content.

CONVERSATION:
{conversation}

Score only based on explicit and observable evidence in the conversation. Do not guess, infer hidden intentions, or assume what the counselor “might” mean. If evidence for an item is insufficient, give a score that reflects the level of evidence shown (e.g., neutral or low). High scores should be reserved only when the conversation provides clear, concrete evidence of the behavior.
Return STRICTLY VALID JSON. No explanations.

TASK:
Score ALL items using:
- WAI → integer 1–5
- CCS → integer 1–5
- BLRI → integer -3 to +3
- Each item independently.

Output JSON ONLY:
{{
  "WAI": {{"item_number": score}},
  "BLRI": {{"item_number": score}},
  "CCS": {{"item_number": score}}
}}

ITEMS:
"""
    for scale_name, dims in criteria.items():
        prompt += f"\n### {scale_name}\n"
        for dim, items in dims.items():
            for num, text in items.items():
                prompt += f"- {scale_name} {num}: {text}\n"
    return prompt


def format_scores_human_readable(scores, criteria):
    output = {}

    def calculate_scale_block(scale_name, dimension_names, score_data):
        block = {}
        all_scale_scores = []
        for dim_name in dimension_names:
            dim_items = criteria[scale_name].get(dim_name, {})
            formatted = {}
            dim_values = []
            for num, text in dim_items.items():
                score = score_data.get(num)
                formatted[f"{num}. {text}"] = score
                if score is not None:
                    try:
                        score_float = float(score)
                        dim_values.append(score_float)
                    except (ValueError, TypeError):
                        pass

            if dim_values:
                formatted["_mean"] = round(sum(dim_values) / len(dim_values), 2)
                all_scale_scores.extend(dim_values)
            else:
                formatted["_mean"] = None

            block[dim_name] = formatted

        if all_scale_scores:
            block["_mean"] = round(sum(all_scale_scores) / len(all_scale_scores), 2)
        else:
            block["_mean"] = None

        return block

    output["WAI_Therapeutic_Relationship (1-5)"] = calculate_scale_block(
        "WAI", ["Goal", "Task", "Bond"], scores.get("WAI", {})
    )

    output["BLRI_Empathic_Understanding (-3 to +3)"] = calculate_scale_block(
        "BLRI", ["Cognitive_Empathy", "Affective_Empathy", "Differentiated_Empathy", "Inner_Pattern"],
        scores.get("BLRI", {})
    )

    output["CCS_R_Counseling_Skills (1-5)"] = calculate_scale_block(
        "CCS", ["Probing", "Facilitate Therapeutic Environment", "Reflecting", "Change_Facilitation"],
        scores.get("CCS", {})
    )

    return output


def calculate_overall_mean_scores(all_scores, criteria):
    overall_means = {}

    for scale_name, dims in criteria.items():
        scale_data = {}
        all_scale_scores_sum = 0
        all_scale_scores_count = 0

        if scale_name == "WAI":
            scale_key_in_data = "WAI_Therapeutic_Relationship (1-5)"
        elif scale_name == "BLRI":
            scale_key_in_data = "BLRI_Empathic_Understanding (-3 to +3)"
        elif scale_name == "CCS":
            scale_key_in_data = "CCS_R_Counseling_Skills (1-5)"
        else:
            continue

        for dim_name, items in dims.items():
            dim_scores_sum = 0
            dim_scores_count = 0

            for sample_data in all_scores.values():
                formatted_scale_data = sample_data.get(scale_key_in_data, {})
                dim_block = formatted_scale_data.get(dim_name, {})
                dim_mean_score = dim_block.get("_mean")

                if isinstance(dim_mean_score, (int, float)):
                    dim_scores_sum += dim_mean_score
                    dim_scores_count += 1

            if dim_scores_count > 0:
                dim_overall_mean = round(dim_scores_sum / dim_scores_count, 2)
                scale_data[dim_name] = dim_overall_mean

                all_scale_scores_sum += dim_overall_mean
                all_scale_scores_count += 1
            else:
                scale_data[dim_name] = None

        if all_scale_scores_count > 0:
            scale_data["_Overall_Mean"] = round(all_scale_scores_sum / all_scale_scores_count, 2)
        else:
            scale_data["_Overall_Mean"] = None

        overall_means[scale_name] = scale_data

    return overall_means


evaluation_samples = {}
try:
    with open(INPUT_FILE_NAME, "r", encoding="utf-8") as f:
        evaluation_samples = json.load(f)
    print(f"✅ Successfully loaded input file: {INPUT_FILE_NAME}, found {len(evaluation_samples)} samples.")
except FileNotFoundError:
    print(f"❌ Error: Input file {INPUT_FILE_NAME} not found. Please ensure the file exists.")
    exit()
except json.JSONDecodeError:
    print(f"❌ Error: Input file {INPUT_FILE_NAME} has incorrect format (not valid JSON).")
    exit()

existing_scores = {}
if os.path.exists(OUTPUT_FILE_NAME) and os.path.getsize(OUTPUT_FILE_NAME) > 0:
    try:
        with open(OUTPUT_FILE_NAME, "r", encoding="utf-8") as f:
            existing_scores = json.load(f)
        if not isinstance(existing_scores, dict):
            existing_scores = {}
            print(f"⚠️ File {OUTPUT_FILE_NAME} content format does not meet requirements, creating new file from scratch.")
    except json.JSONDecodeError:
        print(f"⚠️ File {OUTPUT_FILE_NAME} content is corrupted or incorrectly formatted, creating new file from scratch.")
        existing_scores = {}

for sample_key, dialogue_list in evaluation_samples.items():
    if sample_key in existing_scores:
        print(f"⏭️ Sample {sample_key} already exists in {OUTPUT_FILE_NAME}, skipping API call.")
        continue

    print(f"\n--- Processing sample: {sample_key} ---")

    conversation_text = ""
    for turn in dialogue_list:
        patient_text = turn.get("Patient", "N/A")
        counselor_text = turn.get("Counselor", "N/A")
        conversation_text += f"Patient: {patient_text}\n"
        conversation_text += f"Counselor: {counselor_text}\n"

    prompt = build_prompt(conversation_text, SCORING_CRITERIA)

    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "Return ONLY valid JSON. No code blocks or explanations."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )
        raw_json = response.choices[0].message.content.strip()

        match = re.search(r"\{[\s\S]*\}", raw_json)
        if not match:
            print(f"❌ Scoring failed for sample {sample_key}: JSON not found in model output. Raw output:\n{raw_json[:200]}...")
            sleep(3)
            continue

        json_str = match.group(0)
        scores = json.loads(json_str)

        final_scores = {}
        for scale_name, dims in scores.items():
            final_scores[scale_name] = {}
            if isinstance(dims, dict):
                for item_num, score in dims.items():
                    final_scores[scale_name][str(item_num)] = enforce_range(score, scale_name)

        new_formatted_data = format_scores_human_readable(final_scores, SCORING_CRITERIA)
        existing_scores[sample_key] = new_formatted_data

        print(f"✅ Sample {sample_key} successfully scored.")

    except Exception as e:
        print(f"🚨 API call or processing failed for sample {sample_key}: {type(e).__name__} - {e}")
        sleep(5)
        continue

if existing_scores:
    with open(OUTPUT_FILE_NAME, "w", encoding="utf-8") as f:
        json.dump(existing_scores, f, indent=4, ensure_ascii=False)
    print(f"\n🎉 Batch evaluation completed! All detailed results have been saved to {OUTPUT_FILE_NAME}")

    overall_mean_results = calculate_overall_mean_scores(existing_scores, SCORING_CRITERIA)

    try:
        with open(MEAN_SCORES_OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(overall_mean_results, f, indent=4, ensure_ascii=False)
        print(f"📄 **Overall mean scores summary saved to file**: {MEAN_SCORES_OUTPUT_FILE}")
    except Exception as e:
        print(f"❌ Error: Failed to save overall mean scores file: {e}")

    print("\n" + "=" * 50)
    print("🚀 Batch Evaluation Overall Mean Score Summary (All Samples)")
    print("=" * 50)
    for scale, dims in overall_mean_results.items():
        print(f"\n### {scale} Scale")
        for dim_name, mean_score in dims.items():
            if dim_name != "_Overall_Mean":
                print(f"  * {dim_name:<30}: **{mean_score if mean_score is not None else 'N/A'}**")

        if "_Overall_Mean" in dims:
            print(
                f"  * **{scale} Overall Mean** {' ':<16}: **{dims['_Overall_Mean'] if dims['_Overall_Mean'] is not None else 'N/A'}**")

    print("\n" + "=" * 50)

else:
    print("\n⚠️ Evaluation completed, but no valid scores were generated.")