import json


def batch_process_dialogues(input_file, output_file):
    """
    Batch process dialogue dataset: number each sample and split into dialogue pairs
    :param input_file: Path to original JSON dataset file
    :param output_file: Path to save processed file
    """
    # Read raw data
    with open(input_file, "r", encoding="utf-8") as f:
        raw_data = json.load(f)

    # Store final processed result (organized by sample number)
    final_result = {}

    # Iterate through each dialogue sample, assign number
    for sample_idx, sample in enumerate(raw_data, start=1):
        sample_key = f"sample{sample_idx}"
        final_result[sample_key] = []

        # Extract all messages for current sample
        messages = sample.get("conversations", [])

        # Extract user-assistant dialogue pairs
        for i in range(0, len(messages) - 1, 2):
            user_msg = messages[i]
            assistant_msg = messages[i + 1]

            # Only process valid user-assistant pairs
            if user_msg.get("from") == "human" and assistant_msg.get("from") == "assistant":
                dialog_pair = {
                    "Patient": user_msg["value"].strip(),
                    "Counselor": assistant_msg["value"].strip()
                }
                final_result[sample_key].append(dialog_pair)

    # Save processed result to file (JSON format, easy to view and use later)
    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(final_result, f, indent=4, ensure_ascii=False)

    # Also output plain text format (exactly matching your example format)
    with open(f"{output_file.split('.')[0]}_text.txt", "w", encoding="utf-8") as f:
        for sample_id, dialog_pairs in final_result.items():
            f.write(f"=== {sample_id} ===\n")
            for pair in dialog_pairs:
                f.write(f"{{Patient: {pair['Patient']} Counselor: {pair['Counselor']}}}\n")
            f.write("\n")  # Empty line separator between samples

    print(f"Processing completed!\nJSON format result saved to: {output_file}\nPlain text format saved to: {output_file.split('.')[0]}_text.txt")
    return final_result


# Usage example
if __name__ == "__main__":
    # Replace with your original dataset path
    INPUT_PATH = "/path/to/dataset/original_dataset.json"              
    # Path to save processed file
    OUTPUT_PATH = "/path/to/dataset/processed_dataset.json"

    # Execute batch processing
    processed_data = batch_process_dialogues(INPUT_PATH, OUTPUT_PATH)

    # Print example (view first 2 samples with first 2 dialogues each)
    for idx, (sample_id, pairs) in enumerate(processed_data.items()):
        if idx >= 2:
            break
        print(f"\n【{sample_id}】")
        for p in pairs[:2]:
            print(f"{{Patient: {p['Patient']} Counselor: {p['Counselor']}}}")