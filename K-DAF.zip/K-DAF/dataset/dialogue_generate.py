
import os
import re
import json
import time
import torch
from openai import OpenAI
from sentence_transformers import SentenceTransformer, util
from transformers import pipeline

client = OpenAI(
    api_key="sk-xxx",  # Your API Key
    base_url="https://api.openai.com/v1"  # Base URL for OpenAI API
)


try:
    with open("therapy_methods_detailed_en3.json", "r", encoding="utf-8") as f:
        SK_base = json.load(f)
except FileNotFoundError:
    print("Error: therapy_methods_detailed_en3.json not found.")
    SK_base = []


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")  

emotion_model = pipeline(
    "text-classification",
    model="../model/bert-emotion",
    tokenizer="../model/bert-emotion",
    device=1 if device.type == 'cuda' else -1
)

embedder = SentenceTransformer("../model/all-MiniLM-L6-v2", device=device.type)


stage_metadata = []
texts_to_embed = []

for therapy in SK_base:
    t_name = therapy.get("Therapy", "Unknown")
    core_concept = therapy.get("Core_Concept", "")
    stages = therapy.get("Treatment_Stages", {})
    

    for s_name, s_desc in stages.items():
        stage_metadata.append({
            "therapy_name": t_name,
            "core_concept": core_concept,
            "stage_name": s_name,
            "stage_description": s_desc,
        })
        texts_to_embed.append(f"{s_name}: {s_desc}")

corpus_embeddings = embedder.encode(texts_to_embed, convert_to_tensor=True)


end_expressions = [
    "I feel relieved now",
    "I feel safe now",
    "I feel fully at ease now", "I feel more stable now", "I feel grounded now",
    "I feel really settled now",
    "I feel genuinely calmer now", "I feel completely okay now", "I feel steady again",
    "I feel emotionally balanced now", "I feel more centered now",
    "I feel composed again", "I think that's enough for today", "This feels like a good place to stop",
    "I feel ready to end for today", "I feel done for now",
    "This session feels complete for me", "I’m ready to stop now", "I feel good ending here",
    "I think we covered what I needed today", "I feel satisfied with today’s progress",
    "I feel complete for now", "I'm ready to wrap up", "This is a natural stopping point",
    "That feels like a good closing point", "We can stop here for today",
    "That’s all I need for now", "Thank you, this really helped me", "Thank you, I feel much better now",
    "Thank you, I feel calmer now", "Thank you, I feel lighter",
    "Thanks, I feel a lot better now", "Thanks, this really eased my mind", "Thank you, I feel more at peace",
    "I'm grateful, this helped me a lot", "I truly appreciate this, I feel better now",
    "I feel clear about this now", "I feel ready to move forward", "I feel confident enough for now",
    "I feel more in control now", "I feel settled with this",
    "I have what I need for now", "I feel prepared to take the next steps", "I feel I can handle this now",
    "I feel okay moving on now", "I feel like I've reached a stopping point",
    "I feel calmer thinking about this now", "I feel emotionally lighter now", "I feel okay with this now",
    "I feel more relaxed now", "I feel reassured now",
    "I feel comforted now", "I feel more at peace with this", "I feel my emotions settling",
    "I feel steadier than before", "I feel genuinely okay now",
    "I have a clearer picture now.",
    "I think I understand the core issue.",
    "I feel ready to take a step back and think.",
    "I know what I need to do next.",
    "This gives me a good starting point.",
    "I feel the conversation can end here.",
    "I feel the main point has been made.",
    "I have enough to work on for the week.",
    "I can process this on my own now."
]

ENDING_SUPPORTER_PROMPT = """
You are the Supporter (therapist). The Seeker has reached a natural stopping point.

Your task:
- Offer a warm, gentle, summary-style closing message.
- Do NOT ask questions.
- Do NOT introduce new topics.
- Help the Seeker feel supported and grounded.
- Keep the message under 40 words.

Focus on the Seeker’s last message:
"{last_seeker}"

Write a supportive closing message only.
"""


strong_end_vectors = embedder.encode(end_expressions, convert_to_tensor=True).to(device)

def detect_emotion_label(text: str):
    try:
        res = emotion_model(text)[0]
        return res["label"].lower(), res["score"]
    except:
        return "unknown", 0.0



def split_sentences(text):
    if not text:
        return []
    
    sentences = re.split(r'([.!?])\s*', text)

    segments = []
    for i in range(0, len(sentences), 2):
        sentence = sentences[i].strip()
        if not sentence: continue

        delimiter = sentences[i + 1] if i + 1 < len(sentences) else ''

        if sentence:
            segments.append(sentence + delimiter)

    return segments if segments else [text.strip()]


def get_max_sim_from_segments(text):

    text = text.strip()
    if not text:
        return 0.0

    segments = split_sentences(text)
    if not segments:
        return 0.0

    max_sim = 0.0

   
    for segment in segments:
        
        segment_vector = embedder.encode(segment, convert_to_tensor=True).to(device)


        sims_vector = util.cos_sim(segment_vector, strong_end_vectors)[0]

        
        current_max_sim = sims_vector.max().item()

        
        if current_max_sim > max_sim:
            max_sim = current_max_sim

    return max_sim


def should_end_dialogue(seeker_text, threshold=0.68):  


    debug_info = {}  
    emotion, score = detect_emotion_label(seeker_text)
    negative_set = {"sadness", "anger", "fear", "disgust", "shame", "guilt", "confusion", "sarcasm"}
    debug_info['emotion'] = emotion
    debug_info['score'] = score

    if emotion in negative_set:
        debug_info['max_sim'] = 0.0
        debug_info['end_triggered'] = False
        print(
            f"[Debug] Max similarity: {debug_info['max_sim']:.3f}, Emotion: {debug_info['emotion']}({debug_info['score']:.2f})")
        return False, debug_info

    max_sim = get_max_sim_from_segments(seeker_text)
    debug_info['max_sim'] = max_sim

    print(f"[Debug] Max similarity: {max_sim:.3f}, Emotion: {emotion}({score:.2f})")

    if max_sim >= threshold:  
        print("[Debug] Dialogue ending triggered (emotion + embedding).")
    
        debug_info['end_triggered'] = True
        return True, debug_info

    debug_info['end_triggered'] = False
    return False, debug_info


def extract_json(text: str) -> dict:

    text = (text or "").strip()
    if not text:
        return {"error": "empty_output", "_raw": text}
    try:
        return json.loads(text)
    except Exception:
        pass

    start = None
    stack = 0
    for i, ch in enumerate(text):
        if ch == "{":
            if start is None:
                start = i
            stack += 1
        elif ch == "}":
            if start is not None:
                stack -= 1
                if stack == 0:
                    candidate = text[start:i + 1]
                    try:
                        return json.loads(candidate)
                    except Exception:
                        continue

    return {
        "error": "json_parse_failed",
        "_raw": text
    }


def format_persona(persona_dict):

    big5 = persona_dict.get("big5", {})
    trait_map = {
        "openness": {
            "high": "imaginative and open to new ideas",
            "medium": "open-minded yet practical",
            "low": "prefers routine and familiar experiences"
        },
        "conscientiousness": {
            "high": "organized and reliable",
            "medium": "reasonably responsible and balanced",
            "low": "spontaneous and occasionally careless"
        },
        "extraversion": {
            "high": "outgoing and expressive",
            "medium": "balanced between social and introspective",
            "low": "quiet and reserved"
        },
        "agreeableness": {
            "high": "kind and empathetic",
            "medium": "cooperative yet independent-minded",
            "low": "assertive and skeptical"
        },
        "neuroticism": {
            "high": "emotionally sensitive and often anxious",
            "medium": "emotionally stable with occasional worry",
            "low": "calm and resilient"
        }
    }

    trait_desc = []
    for trait, level in big5.items():
        if trait in trait_map and level in trait_map[trait]:
            trait_desc.append(trait_map[trait][level])

    if trait_desc:
        personality_summary = ", ".join(trait_desc[:-1]) + \
                              (", and " + trait_desc[-1] if len(trait_desc) > 1 else trait_desc[0]) + "."
    else:
        personality_summary = ""

    return (
        f"You are a {persona_dict.get('age', 'unknown')}-year-old {persona_dict.get('gender', '')} "
        f"working as a {persona_dict.get('occupation', 'unknown')}. "
        f"You have an education level of {persona_dict.get('education_level', 'unspecified')}. "
        f"You often think: \"{persona_dict.get('thought', '')}\". "
        f"You are {personality_summary}." if personality_summary else ""
    )


def retrieve_top_k_stages(next_intervention, k=5):
    
    query_embedding = embedder.encode(next_intervention, convert_to_tensor=True).to(device)
    cos_scores = util.cos_sim(query_embedding, corpus_embeddings)[0]
    top_indices = cos_scores.topk(k).indices.tolist()
    return [stage_metadata[i] for i in top_indices]


def reason_select_stage(emotion, observed_change, next_intervention, stage_candidates):
    prompt = f"""
You are a Clinical Strategy Selector. 
Your goal is to pick the single most effective therapeutic STAGE based on the seeker's current state.

Context:
- Current Emotion: {emotion}
- Observed Change: {observed_change}
- Target Intervention: {next_intervention}

Candidates (Specific Stages from different Therapies):
{json.dumps(stage_candidates, indent=2, ensure_ascii=False)}

Task:
Analyze which specific stage's description and techniques best match the "Target Intervention".
Output JSON only:
{{
  "chosen_therapy": "<Therapy Name>",
  "chosen_stage_name": "<Stage Name>",
  "chosen_stage_description": "<Description>",
  "reason": "<Brief clinical reasoning>"
}}
"""
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return extract_json(response.choices[0].message.content)


SEEKER_ROUND1_PROMPT = """
You are the Seeker in a psychotherapy conversation (Round 1).

Your core recurring thought or fear is:
"{core_thought}"

Persona Summary:
{persona_text}

----------------------------------------------------------------------
CORE INSTRUCTION: CONCRETE STARTING POINT
----------------------------------------------------------------------

Your task is to generate the first, introductory message for the psychotherapy session.

Your response must be an **unfiltered, concrete expression** of your core recurring thought or a recent event directly related to it.

Guidelines:
1. **Be Specific:** Directly state the specific problem you are bringing to the session.
2. **Anchor to Context:** Ensure the content reflects the specific **context** (e.g., job, relationship, sport) implied by your "{core_thought}".
3. **Avoid Vague Generalities:** Do NOT start with vague feelings like "I feel bad" or generic introductions.
4. **Response Style:** Remain under 30 words, showing initial emotional tension (anxiety, uncertainty, confusion).

Generate your opening message for Round 1 only.
"""

SEEKER_PROMPT = """
You are the Seeker in a psychotherapy conversation

Here are the last few rounds of the conversation:
{conversation_history}

Persona Summary:
{persona_text}

Your core fear is:
"{core_thought}"

Your tone, internal logic, and emotional reactions must remain consistent with your persona and core fear throughout the entire conversation.

----------------------------------------------------------------------
EMOTIONAL PROGRESSION (VERY IMPORTANT)
----------------------------------------------------------------------

Your emotional state should evolve gradually based on the Supporter’s input and the stage of the conversation.



Improvements must be:
- **Gradual**
- **Emotionally believable**
- **Directly tied to something the Supporter just said**


These should still feel natural, not dramatic or sudden.


GLOBAL RULES:
- Gratitude must always be emotionally meaningful, not polite.
- Avoid starting sentences with “I feel…”, and use it sparingly.

----------------------------------------------------------------------
COGNITIVE PATTERN RULES
----------------------------------------------------------------------

- Stay anchored to your core fear.
- Insights should emerge gradually, not suddenly.
- If the Supporter explores evidence or reasoning, respond with honest uncertainty or small realizations.

----------------------------------------------------------------------
RESPONSE STYLE
----------------------------------------------------------------------

Your response must:
- Remain under 30 words.
- Directly respond to the Supporter’s latest message.
- Show emotional authenticity and internal processing.
- Maintain continuity with your prior messages.
- Feel like real psychotherapy, not narration.

DO NOT:
- Produce overly long answers.
- Skip emotional realism.

----------------------------------------------------------------------
Your previous message was:
{last_seeker}

The Supporter just said:
"{last_supporter}"

"""

STATE_TRACKER_PROMPT = """
You are the State Tracking Agent in a psychotherapy system.

Analyze the Seeker’s latest message in comparison to their previous message.
and output a structured JSON with exactly 3 fields:
{{
  "emotion": "...",
  "observed_change": "...",
  "next_intervention": "...",
}}

Definitions:
- emotion: Seeker’s current emotional state.
- observed_change: emotional or cognitive shift compared to their previous message.
- next_intervention: recommended direction for Supporter to guide next.

Seeker’s previous message:
{previous_text}

Seeker’s latest message:
{seeker_text}

Output JSON only (no markdown).
"""

SUPPORTER_PROMPT = """
You are a professional Supporter (therapist) in a psychotherapy conversation.

The Seeker's core underlying fear/thought is: "{core_thought}"
(Maintain relevance to the Seeker’s core_thought. Use this to inform your empathy and guidance.)

Here are the last few rounds of the conversation:
{conversation_history}

The Seeker's current state: {emotion}. 
Observed change: {observed_change}.
Last message from Seeker: "{last_seeker}"

You are currently applying the "{chosen_stage_name}" stage from {chosen_therapy}.
Stage Guidance: {chosen_stage_description}

Your role:
- Respond as an emotionally attuned, professional, and warm supporter.
- Prioritize understanding, validating, and emotionally supporting the Seeker.
- Maintain a natural tone that aligns with the previous conversation flow.
- Balance empathy, reassurance, gentle guidance, and (when appropriate) reflective questioning.

Response principles:
- Offer emotional comfort or normalization when distress or vulnerability is present.
- When appropriate, include one gentle, practical, and emotionally supportive suggestion that feels optional, not prescriptive.
- If a question is included, place it after supportive statements, not at the beginning.
- Do NOT explicitly mention the therapy name or the stage name in your response.

Your task:
- Build directly on the Seeker’s last message.
- Be emotionally coherent, warm, and specific.
- Apply therapeutic principles implicitly through tone, empathy, and gentle guidance.
- Avoid abrupt topic shifts, technical jargon, or generic reassurance.

Length constraint:
- No more than 40 words.

Return only your message text (no labels, no explanations).
"""

def call_model(prompt, temperature=0.6, retries=3, delay=2, log_file="dialogue_debug_log.txt"):
    for attempt in range(1, retries + 1):
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature
            )
            choices = getattr(response, "choices", [])
            if choices and getattr(choices[0], "message", None):
                content = getattr(choices[0].message, "content", None)
                if content:
                    return content.strip()
            raise ValueError(f"Empty response content on attempt {attempt}")
        except Exception as e:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(f"❌ [Attempt {attempt}] call_model failed: {e}\n")
            if attempt < retries:
                time.sleep(delay)
            else:
                return "[No response]"


def log_to_file(text, log_file="dialogue_debug_log.txt"):
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(text + "\n")


def call_state_tracker(previous_text, seeker_text, retries=3, delay=2, log_file="dialogue_debug_log.txt"):
    prompt = STATE_TRACKER_PROMPT.format(previous_text=previous_text, seeker_text=seeker_text)
    raw_output = call_model(prompt, temperature=0, retries=retries, delay=delay, log_file=log_file)
    try:
        return extract_json(raw_output)
    except Exception as e:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"❌ State Tracker parsing failed: {e}\nRaw output: {raw_output}\n")
        return {"emotion": "", "observed_change": "", "next_intervention": ""}



def simulate_dialogue(persona: dict, rounds: int, record_id: str, strategy: str, log_file: str):
    results = []
    last_seeker = ""
    last_supporter = ""
    persona_text = format_persona(persona)
    history = []
    end_debug_info = {}
    ending_triggered = False
    round_num = 0

    try:
        log_to_file(f"=== Simulation Start for Record ID: {record_id} ({strategy}) ===", log_file)

        for round_num in range(1, rounds + 1):
            print(f"\n🌀 Record {record_id} | Round {round_num}")
            log_to_file(f"\n\n===================== ROUND {round_num} =====================", log_file)

            if history:
                conversation_history = "\n---\n".join(
                    [f"Round {h['round']} | {h['role'].capitalize()}: {h['content']}"
                     for h in history[-6:]]
                )
            else:
                conversation_history = "No previous conversation."

            if round_num == 1:
                seeker_prompt = SEEKER_ROUND1_PROMPT.format(
                    core_thought=persona.get("thought", ""),
                    persona_text=persona_text,
                )
            else:
                seeker_prompt = SEEKER_PROMPT.format(
                    round_num=round_num,
                    core_thought=persona.get("thought", ""),
                    prev_round_num=round_num - 1,
                    persona_text=persona_text,
                    conversation_history=conversation_history,
                    last_seeker=last_seeker,
                    last_supporter=last_supporter
                )

            seeker_utt = call_model(seeker_prompt, temperature=0.6, retries=3, log_file=log_file) or "[No response]"
            print(f"👤 Seeker: {seeker_utt}")
            log_to_file(f"[Seeker Output]\n{seeker_utt}\n", log_file)
            ending_triggered, end_debug_info = should_end_dialogue(seeker_utt)
            log_to_file(f"[Ending Detection Info]\n{json.dumps(end_debug_info, indent=2)}\n", log_file)

            history.append({"round": round_num, "role": "seeker", "content": seeker_utt})

         
            if ending_triggered or round_num == rounds:
                closing_prompt = ENDING_SUPPORTER_PROMPT.format(last_seeker=seeker_utt)
                supporter_utt = call_model(closing_prompt, temperature=0.6, log_file=log_file) or "[No response]"
                print(f"🤝 Supporter (closing): {supporter_utt}")
                log_to_file(f"[Supporter Closing Output]\n{supporter_utt}\n", log_file)

                history.append({"round": round_num, "role": "supporter", "content": supporter_utt})

                results.append({
                    "round": round_num,
                    "seeker": seeker_utt,
                    "state_report": {},
                    "chosen_stage": {}, 
                    "supporter": supporter_utt,
                    "ending_debug_info": end_debug_info
                })
                break

        
            prev_seeker_utt = next((h['content'] for h in reversed(history[:-1]) if h['role'] == 'seeker'), "")
            report = call_state_tracker(prev_seeker_utt, seeker_utt, log_file=log_file)
            log_to_file(f"[State Tracker Output]\n{json.dumps(report, ensure_ascii=False, indent=2)}\n", log_file)

            candidates = retrieve_top_k_stages(report.get("next_intervention", ""), k=5)
            log_to_file(f"[Retrieved Top-5 Stages]\n{json.dumps(candidates, ensure_ascii=False, indent=2)}\n", log_file)

            chosen = reason_select_stage(
                report.get("emotion", ""),
                report.get("observed_change", ""),
                report.get("next_intervention", ""),
                candidates
            )
            log_to_file(f"[Reason Select Stage Output]\n{json.dumps(chosen, ensure_ascii=False, indent=2)}\n", log_file)

            supporter_prompt = SUPPORTER_PROMPT.format(
                round_num=round_num,
                prev_round_num=round_num - 1,
                last_seeker=seeker_utt,
                conversation_history=conversation_history,
                emotion=report.get("emotion", ""),
                observed_change=report.get("observed_change", ""),
                core_thought=persona.get("thought", ""),
                chosen_therapy=chosen.get("chosen_therapy", ""),
                chosen_stage_name=chosen.get("chosen_stage_name", ""),
                chosen_stage_description=chosen.get("chosen_stage_description", ""),
            )

            supporter_utt = call_model(supporter_prompt, temperature=0.6, log_file=log_file) or "[No response]"
            print(f"🤝 Supporter: {supporter_utt}")
            log_to_file(f"[Supporter Output]\n{supporter_utt}\n", log_file)

            history.append({"round": round_num, "role": "supporter", "content": supporter_utt})

            last_seeker, last_supporter = seekesr_utt, supporter_utt

            results.append({
                "round": round_num,
                "seeker": seeker_utt,
                "state_report": report,
                "chosen_stage": chosen,
                "supporter": supporter_utt,
                "ending_debug_info": end_debug_info
            })

            log_to_file("==============================================================\n", log_file)
            time.sleep(1)

    except Exception as e:
        print(f"❌ Simulation for Record {record_id} interrupted: {e}")
        log_to_file(f"❌ Simulation for Record {record_id} interrupted: {e}\n", log_file)
        raise
    return {
        "record_id": record_id,
        "strategy": strategy,
        "persona": persona,
        "dialogue_history": results,
        "completion_status": "Ended_Semantically" if ending_triggered else (
            "Completed_Max_Rounds" if round_num == rounds else "Interrupted"),
        "ending_info": end_debug_info
    }


def generate_dataset(personas_file="personas.json", rounds=20,
                     output_file="conversation/full_psychotherapy_dataset.json"):  
    

    try:
        with open(personas_file, "r", encoding="utf-8") as f:
            personas_list = json.load(f)
        if not isinstance(personas_list, list):
            print(f"Error: {personas_file} must contain a list of personas.")
            return
    except (FileNotFoundError, json.JSONDecodeError) as e:
        print(f"Error reading persona file: {e}")
        return


    ts = int(time.time())
    log_file = f"dialogue_batch_log_{ts}.txt"
    open(log_file, "w", encoding="utf-8").close()

    dir_name = os.path.dirname(output_file)
    if dir_name and not os.path.exists(dir_name):
        os.makedirs(dir_name)
        print(f"📂 Created directory: {dir_name}")

    final_output_file = output_file.format(timestamp=ts)

    print(f"🚀 Starting dataset generation for {len(personas_list)} personas...")
    print(f"💾 Output file: {final_output_file} (Sequential and robust writing enabled)")

    is_first_record = True  

    try:
        with open(final_output_file, "w", encoding="utf-8") as f:
            f.write("[\n")

            try:
                for i, persona_data in enumerate(personas_list):

                    record_id = f"P{i + 1:03d}"
                    strategy = "Hybrid_Dynamic"

                    print(f"\n========================================================")
                    print(f"Processing Sample {i + 1}/{len(personas_list)}: ID {record_id}")
                    print(f"========================================================")

                    record = simulate_dialogue(
                        persona=persona_data,
                        rounds=rounds,
                        record_id=record_id,
                        strategy=strategy,
                        log_file=log_file
                    )

                    record['sample_index'] = i + 1

                    if not is_first_record:
                        f.write(",\n")

                    json.dump(record, f, ensure_ascii=False, indent=2)

                    is_first_record = False

                    f.flush()

                    time.sleep(1)

            except Exception as e_inner:
                print(
                    f"\n❌ CRITICAL ERROR: An exception occurred during the loop (Sample {i + 1}, ID {record_id}). Error: {e_inner}")
                pass

            finally:
                f.write("\n]")
                print(f"\n[Cleanup] Successfully wrote the closing JSON bracket to {final_output_file}.")

        print(f"\n✅ Dataset generation complete. All processed records saved to {final_output_file}")

    except Exception as e_outer:
        print(f"\n❌ A fatal error occurred outside the processing loop. Error: {e_outer}")
        print(
            f"⚠️ Check {final_output_file} for processed data. The file should be a valid JSON array up to the point of failure.")

    return final_output_file


if __name__ == "__main__":
    output_filename = generate_dataset(
        personas_file="/path/to/persona/test.json",
        rounds=20,
        output_file="/path/to/conversation/test/PsyDAF_{timestamp}.json"
    )