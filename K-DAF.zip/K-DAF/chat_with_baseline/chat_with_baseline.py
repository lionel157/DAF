# -*- coding: utf-8 -*-
"""
AI Seeker (External LLM) & Local AI Supporter (Llama-3-8B LoRA)
Pure dialogue generation system
Modified: Strictly aligned with Llama-3 Chat Template (No System Prompt)
"""

import os
import re
import json
import time
import torch
import signal
import sys
from openai import OpenAI
from transformers import pipeline

OUTPUT_FILENAME = "conversation/DAF-chat-result.json"
records = {}

# ==========================
# 1. API Configuration (Seeker)
# ==========================
client = OpenAI(
    api_key="sk-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",
    base_url="https://api.example.com/v1"
)

# ==========================
# 2. Local Model Configuration (Supporter)
# ==========================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

LOCAL_MODEL_PATH = "/path/to/your/models/DAF-chat"
supporter_generator = None

try:
    supporter_generator = pipeline(
        "text-generation",
        model=LOCAL_MODEL_PATH,
        tokenizer=LOCAL_MODEL_PATH,
        device=0 if device.type == "cuda" else -1,
        torch_dtype=torch.float16 if device.type == "cuda" else torch.float32
    )
    print("✅ Local Supporter model (Llama-3 LoRA) loaded.")
except Exception as e:
    print(f"❌ Failed to load local model: {e}")

# ==========================
# 3. Persona Formatting
# ==========================
def format_persona(persona):
    trait_map = {
        "openness": {"high": "imaginative and open to new ideas", "medium": "curious yet practical", "low": "practical and prefers routine"},
        "conscientiousness": {"high": "organized and reliable", "medium": "generally responsible", "low": "spontaneous and disorganized"},
        "extraversion": {"high": "outgoing and energetic", "medium": "social yet reflective", "low": "quiet and reserved"},
        "agreeableness": {"high": "kind and cooperative", "medium": "cooperative but independent", "low": "direct and skeptical"},
        "neuroticism": {"high": "emotionally sensitive and anxious", "medium": "emotionally responsive", "low": "calm and resilient"}
    }
    parts = [f"You are a {persona.get('age', 'unknown')}-year-old {persona.get('gender', '')} working as a {persona.get('occupation', 'unknown')}."]
    parts.append(f"You have an education level of {persona.get('education_level', 'unspecified')}.")
    parts.append(f'You often think: "{persona.get("thought", "")}".')
    traits = []
    for t in ["openness", "conscientiousness", "extraversion", "agreeableness", "neuroticism"]:
        level = persona.get("big5", {}).get(t)
        if level in trait_map[t]:
            traits.append(trait_map[t][level])
    if traits:
        parts.append("You are " + ", ".join(traits[:-1]) + (" and " + traits[-1] if len(traits) > 1 else traits[0]) + ".")
    return " ".join(parts)

# ==========================
# 4. Seeker Prompts
# ==========================
SEEKER_ROUND1_PROMPT = """You are the client in a psychotherapy conversation. This is your very first statement.
Persona: {persona_text}
Thought: "{core_thought}"
Instruction: Concisely describe the core external event (under 30 words) with emotional tension."""

SEEKER_PROMPT = """You are the client. History: {conversation_history}
Persona: {persona_text}
The therapist said: "{last_supporter}"
Response (under 30 words): Directly respond as the patient."""

# ==========================
# 5. Llama-3 Chat Template Builder (Core fix)
# ==========================
def build_supporter_dialogue(history, tokenizer, max_turns=6):
    """
    Build LLaMA-3 chat prompt strictly aligned with LLaMA-Factory (sharegpt),
    using only the most recent turns to avoid context dilution.
    """
    messages = []
    
    # Keep only recent max_turns (seeker + supporter turns)
    for h in history[-max_turns:]:
        role = "user" if h["role"] == "seeker" else "assistant"
        messages.append({
            "role": role,
            "content": h["content"]
        })

    prompt = tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )
    return prompt

# ==========================
# 6. Model Calls & Post-Processing
# ==========================
def call_external_model(prompt):
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.6
    )
    return response.choices[0].message.content.strip()

def robust_post_process(text):
    """
    Post-processing: truncate repetitive sentences to prevent looping
    """
    if not text: return ""
    
    # Truncate repetitive "The assistant is here..." or similar machine-generated text
    # Logic: if a sentence already appears in current response, consider it as looping and truncate
    sentences = re.split(r'(?<=[。！？\.!\?])\s*', text)
    seen = set()
    clean_sentences = []
    for s in sentences:
        s_strip = s.strip()
        if not s_strip: continue
        if s_strip in seen or "The assistant" in s_strip or "How does this resonate" in s_strip:
            break
        seen.add(s_strip)
        clean_sentences.append(s_strip)
    
    return "".join(clean_sentences)

def call_local_supporter_model(prompt, max_tokens=100):
    if supporter_generator is None:
        return "[Local model not loaded]"
    
    # Get Llama-3 end token IDs
    tokenizer = supporter_generator.tokenizer
    eos_ids = [tokenizer.eos_token_id, tokenizer.convert_tokens_to_ids("<|eot_id|>")]

    res = supporter_generator(
        prompt,
        max_new_tokens=max_tokens,
        do_sample=True,
        temperature=0.6,
        top_p=0.9,
        repetition_penalty=1.15, # Must add repetition penalty
        eos_token_id=eos_ids,
        pad_token_id=tokenizer.eos_token_id,
        return_full_text=False
    )
    
    text = res[0]["generated_text"].strip()
    text = robust_post_process(text)
    return text

# ==========================
# 7. Dialogue Simulation
# ==========================
def simulate_dialogue(persona, rounds, record_id):
    history = []
    persona_text = format_persona(persona)
    last_supporter = ""
    results = []

    print(f"\n--- 🌀 Generating: {record_id} ---")

    for r in range(1, rounds + 1):
        if r == 1:
            f_prompt = SEEKER_ROUND1_PROMPT.format(persona_text=persona_text, core_thought=persona.get("thought", ""))
        else:
            seeker_history = "\n".join([f"{h['role']}: {h['content']}" for h in history[-4:]])
            f_prompt = SEEKER_PROMPT.format(persona_text=persona_text, conversation_history=seeker_history, last_supporter=last_supporter)

        # Patient Turn
        seeker = call_external_model(f_prompt)
        seeker = re.sub(r'^(Patient|Seeker):\s*', '', seeker, flags=re.IGNORECASE).strip()
        history.append({"role": "seeker", "content": seeker})

        # Counselor Turn
        # Pass tokenizer to build Chat Template
        supporter_input = build_supporter_dialogue(history, supporter_generator.tokenizer)
        supporter = call_local_supporter_model(supporter_input)
        history.append({"role": "supporter", "content": supporter})
        last_supporter = supporter

        print(f"[{record_id} | Round {r:02d}]")
        print(f"  Patient: {seeker}")
        print(f"  Counselor: {supporter}")
        results.append({"Patient": seeker, "Counselor": supporter})
        time.sleep(0.5)

    return results

# ==========================
# 8. Main Execution (with checkpoint resume)
# ==========================
def save_on_exit(signum=None, frame=None):
    global records
    if records:
        os.makedirs(os.path.dirname(OUTPUT_FILENAME), exist_ok=True)
        with open(OUTPUT_FILENAME, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        print(f"\n🚨 Data saved to {OUTPUT_FILENAME}")
    if signum: sys.exit(1)

signal.signal(signal.SIGINT, save_on_exit)
signal.signal(signal.SIGTERM, save_on_exit)

if __name__ == "__main__":
    # 1. Ensure output directory exists
    os.makedirs(os.path.dirname(OUTPUT_FILENAME), exist_ok=True)

    # 2. Try to load existing records
    if os.path.exists(OUTPUT_FILENAME):
        try:
            with open(OUTPUT_FILENAME, "r", encoding="utf-8") as f:
                records = json.load(f)
            print(f"📦 Detected existing progress, loaded {len(records)} conversation records.")
        except Exception as e:
            print(f"⚠️ Failed to read old records (may be corrupted): {e}")
            records = {}
    else:
        records = {}

    # 3. Load Persona list
    try:
        with open("/path/to/your/persona_dataset/sample_150.json", "r", encoding="utf-8") as f:
            personas = json.load(f)
    except Exception as e:
        print(f"❌ Persona file error: {e}")
        sys.exit(1)

    # 4. Start loop
    for i, p in enumerate(personas):
        sample_key = f"sample{i+1}"
        
        # --- Checkpoint logic: skip if key already exists ---
        if sample_key in records:
            continue 
            
        try:
            # Execute dialogue simulation
            records[sample_key] = simulate_dialogue(p, 15, sample_key)
            print(f"--- ✅ {sample_key} Done ({i+1}/{len(personas)}) ---")
            
            # --- Added: save after each generation to prevent data loss ---
            save_on_exit()
            
        except Exception as e:
            print(f"❌ Error at {sample_key}: {e}")
            save_on_exit() # Final save before crash
            break

    save_on_exit()
    print("✅ All tasks completed.")